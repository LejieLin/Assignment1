#include <string>
using namespace std;

class Student {
public:
    Student() {}
    string FirstName() {
        return "Lejie";
    }

    string LastName() {
        return "Lin";
    }

    int StudentIdentifier() {
        return 2069983;
    }
};